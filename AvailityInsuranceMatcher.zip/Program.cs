﻿using System;

namespace Availity_InsuranceMatcher
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("");
        }
    }
}
